def main():
  print("sIMBA executed")


if __name__ == '__main__':
  main()
